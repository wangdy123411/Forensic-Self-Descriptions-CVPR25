"""Keep Windows awake only while this experiment/verification is running.

The request belongs to this process's thread and expires on exit. It does not
write a power plan or registry setting.
"""
from __future__ import annotations
import ctypes
import json
from pathlib import Path
import time

AN = Path(__file__).resolve().parent


def main():
    continuous, system_required = 0x80000000, 0x00000001
    set_state = ctypes.windll.kernel32.SetThreadExecutionState
    set_state.argtypes = [ctypes.c_uint]
    set_state.restype = ctypes.c_uint
    if not set_state(continuous | system_required):
        raise OSError("Windows did not accept the temporary keep-awake request")
    print("Temporary keep-awake request active for the local experiment.", flush=True)
    deadline = time.monotonic() + 3 * 3600
    try:
        while time.monotonic() < deadline:
            if (AN / "results" / "main" / "verification.json").exists():
                break
            status_path = AN / "results" / "pipeline_status.json"
            if status_path.exists():
                try:
                    state = json.loads(status_path.read_text())
                except json.JSONDecodeError:
                    state = {}
                if state.get("stage") == "error":
                    break
            time.sleep(20)
    finally:
        set_state(continuous)
        print("Temporary keep-awake request released.", flush=True)


if __name__ == "__main__":
    main()
