# AN robustness results

Completed 8 November 2026 using official upstream main commit `50f2eae06efdac2e5a33f407ca9a27a2295133ac` with explicit v1.2.0 release weights on the RTX 2060, inside `an/.venv`. The source is distinct from the earlier `v1.2.0` tag; [source verification](baseline_comparison/source_verification.md) records the attribution and default-weight differences. **All 5,800 cases completed with zero errors.** The main finding is substantial sensitivity to resizing and cropping. Good clean detection and high AUROC after some processing do not guarantee reliable decisions at the original threshold.

The [full report](results/main/report.md) contains all conditions, source-level results, uncertainty intervals, residual galleries, and runtime plots. The [research audit](docs/research.md) documents the upstream repository, paper, related implementations, training/test datasets, and paper-versus-release differences. [README](README.md) gives execution and reproduction commands.

## What ran

The fixed test set contains 100 COCO photographs and 50 images each from Synthbuster's DALL-E 3, Adobe Firefly, Stable Diffusion XL, and GLIDE sources. Another 100 COCO photographs were reserved for clean-only threshold calibration. Every test original received the same 19 conditions: clean; three JPEG qualities; three resize factors; three center-crop areas; three blur strengths; three sharpening amounts; and three resize-then-JPEG combinations. This gives 300 × 19 + 100 = 5,800 cases.

Weights were fixed throughout. No detector retraining or threshold selection on transformed test images was performed. All downloaded originals, weights, manifests, scripts, cached 960D features, logs, and results are under `an/`.

## Main measurements

AUROC measures ranking, with larger anomaly scores indicating synthetic images. TPR is the fraction of synthetic images detected; FPR is the fraction of real photographs falsely flagged. The table uses the release's unchanged `z < -2` decision threshold. These are selected illustrative conditions; the full 19-condition table is in the report.

| Processing | Macro AUROC | Synthetic TPR | Real FPR |
| --- | ---: | ---: | ---: |
| Clean | 0.9953 | 94.5% | 2.0% |
| JPEG Q75 | 0.9886 | 85.0% | 2.0% |
| JPEG Q50 | 0.9673 | 73.0% | 3.0% |
| Resize to half width/height | 0.5898 | 46.5% | 2.0% |
| Center crop retaining 25% area | 0.5916 | 49.0% | 5.0% |
| Gaussian blur radius 2 | 0.9918 | 66.5% | 1.0% |
| Unsharp mask amount 200% | 0.9955 | 94.5% | 2.0% |
| Half-size resize, then JPEG Q50 | 0.6308 | 46.0% | 4.0% |

Clean macro AUROC has a 95% bootstrap interval of **0.9903–0.9992**. Half-size resizing changes AUROC by **−0.4055**, with paired 95% interval **−0.4376 to −0.3773**. Cropping to 25% area changes it by **−0.4037**, with interval **−0.4325 to −0.3736**. Intervals use 1,000 paired, source-stratified bootstrap draws; they are pointwise and are not adjusted for the whole sweep.

The geometric losses differ sharply by generator. Under half-size resizing, AUROC is 0.9846 for Firefly, 0.9686 for DALL-E 3, **0.0386 for GLIDE**, and **0.3674 for SDXL**. Below-chance results retain the original scoring direction; scores were not reversed after seeing test outcomes. Balanced source counts make pooled and generator-macro AUROC coincide in this study.

Effects are not monotonic in nominal severity: quarter-size resizing has AUROC 0.8477, higher than half-size resizing, while its release-threshold TPR is only 28.0%. Likewise, blur radius 2 retains high AUROC but loses 28 percentage points of TPR relative to clean. A statement that FSD is simply “robust to blur” would miss this operating-threshold failure.

The separate clean-real calibration produces anomaly cutoff 0.993903, with clean-test TPR/FPR of 97.5%/4.0%. Keeping that threshold fixed, crop-to-50%-area FPR rises to 12.0%. Calibration on clean images alone does not control false alarms after every processing operation.

## Residuals, descriptors, and attribution

Across all 300 paired test originals, median raw 960D relative L2 drift is **1.036** for half-size resizing and **1.025** for cropping to 25% area, compared with **0.060** for JPEG Q95. The corresponding detection-projected drift is almost unchanged at this metric's precision. These measurements support substantial descriptor sensitivity to geometry; they do not prove a unique causal mechanism.

Residual amplitude alone does not explain task performance. Blur radius 2 reduces median post-preprocessing residual RMS to **0.065× clean**, yet AUROC remains 0.9918. Sharpening at 200% raises it to **2.576× clean**, with AUROC 0.9955. FSD fits constrained relationships between residual neighbors, so amplitude, spatial structure, density scores, and the decision threshold must be considered together. The release also internally resizes/crops residuals to 1024, including upsampling small inputs; this study measures that complete released pipeline.

![Paired detection results](results/main/plots/auroc_by_condition.png)

Supported-source attribution is much weaker than detection. On 150 images from the three exactly mapped generators, full 14-way classifier top-1 accuracy is **39.3% clean**: Firefly 100%, DALL-E 3 12%, SDXL 6%. It falls to **4.0% at JPEG Q50** and **0% for each tested resize factor**. The clean baseline already needs investigation. GLIDE has no matching checkpoint label and is excluded from accuracy; its predictions are descriptive only. These are closed-set results, with no unknown-rejection or open-set robustness claim.

## Recommendations

1. **Make geometric processing the primary AN finding.** Replicate half-size resizing and crop-to-25%-area on a larger held-out sample and another real-camera domain. Show the per-generator heatmap alongside the aggregate; the severe GLIDE/SDXL losses are hidden by strong Firefly/DALL-E 3 performance.
2. **Report AUROC and frozen-threshold TPR/FPR together.** JPEG and blur demonstrate that ranking can remain strong while many synthetic images cross the decision threshold. A follow-up can calibrate on separately held-out processed real images, then test on fresh originals and unseen severities. Such calibration cannot by itself repair the severe ranking reversals.
3. **Test the internal geometry as a separate controlled ablation.** Compare the released residual resize/crop path with native-resolution crops or crop aggregation, and sweep additional interpolation kernels. These alternatives may change the model's feature distribution and must be validated independently; they were not silently substituted into this benchmark.
4. **Validate attribution before treating it as a reliable output.** Investigate the low clean DALL-E 3/SDXL baseline, checkpoint/source-domain mismatch, and the released feature transforms. Any unknown-rejection extension needs whole held-out generators and a separate calibration protocol. Softmax confidence alone is insufficient.
5. **Extend simulations to measured sharing workflows.** A later study can compare original images with actual downloaded outputs from a chosen platform, record dimensions/encoding, and test processing order, repeated JPEG saves, and random crops. The current resize→JPEG tests are controlled simulations, not evidence about a particular service.

These mitigation ideas are proposed follow-ups. This completed run establishes the baseline and processing failures; it does not claim that a mitigation has already improved performance.

## Reliability and scope

- [Final verification](results/main/verification.json) passed for all 5,800 records, all cached 960D feature vectors, original hashes, merged artifacts, 14 PNG figures, and 28 report links. [Independent data audit](results/main/independent_data_audit.json) confirms coverage and provenance. All 30 automated tests passed.
- The memory-efficient FFT extractor preserves the released float64 objective and was initially compared against the AN direct tiled reference, not literal upstream full-patch extraction. In those 16 actual-image checks, maximum relative FSD error and absolute z-score error were approximately 1.78e−6, with all source predictions unchanged. The completed [direct upstream follow-up](baseline_comparison/RESULTS.md) then executed the original default-1024 function on 25 originals under seven conditions: all 175 detection/source predictions match, maximum raw relative L2 difference is 3.40e−7, and maximum absolute z difference is 3.54e−7. Matched task metrics are identical; median paired speedup is 15.07× on this PC. This smaller validation cohort does not replace the 300-original study. See [numerical fidelity](docs/implementation_notes.md).
- A supplementary [shared-content sensitivity analysis](results/main/content_sensitivity.md) resamples 181 archive-stem proxy groups, including 18 stems shared across generators. The main geometric-loss conclusions remain under those intervals. These unconfirmed proxies cannot establish full prompt/content independence.
- This is a 300-test-original, four-generator, one-real-domain study of the **released checkpoint**, not the full paper benchmark. Calibration and test originals are disjoint locally; checkpoint-training overlap cannot be excluded because original training manifests are unavailable. COCO and selected Firefly inputs already contain JPEG encoding. RAISE acquisition failed and no RAISE result is claimed.

GPU scoring ran from approximately **13:42 to 16:15 Singapore time**, totaling **2 hours 33 minutes** across both phases. Mean measured test-case processing time was 1.58 seconds, with maximum allocated GPU tensor memory 871 MiB; device-wide telemetry includes additional driver/application memory. These timings reflect the observed warm machine state, including thermal slowdown. The earlier environment-held download request pushed total task wall time beyond the requested 6–7 hours; that waiting time is documented separately from compute time.
