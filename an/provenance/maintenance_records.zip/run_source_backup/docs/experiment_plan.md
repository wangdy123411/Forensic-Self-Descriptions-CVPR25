# AN: processing robustness experiment

Prepared before inspecting benchmark scores. The task is the AN column in the supplied project-plan image.

## Research question

How does ordinary image processing affect the released FSD detector, its source predictions, residuals, and 960-dimensional descriptors? This is a fixed-checkpoint robustness study, not a reconstruction of the paper's complete training/evaluation pipeline.

## Fixed model and numerical implementation

- Fork: `wangdy123411/Forensic-Self-Descriptions-CVPR25`; upstream: `ductai199x/Forensic-Self-Descriptions-CVPR25`.
- Local revision: `50f2eae06efdac2e5a33f407ca9a27a2295133ac`.
- Official v1.2.0 weights are stored under `an/weights/v1.2.0`, with SHA-256 records in `an/weights_provenance.json`.
- Loaded FRE: 8 channels, 15×15 convolution. FSD: 11×11 neighborhoods excluding centers, 3 scales, 960 features, 1024 residual-grid size, released `resize_and_crop` preprocessing.
- All extraction and scoring use float64. The FFT implementation accumulates the same normal equations as the release, with explicit corrections from circular to reflection padding. It changes summation order, not the objective or sample set. Compare against the direct implementation before production; retain the numerical audit records.
- No gradients, model training, test-set threshold fitting, or fake-image detector training.

## Processing grid

All transforms are applied in RGB image space, before the released grayscale/FRE pipeline. Every test original receives every condition.

| Family | Settings | Exact interpretation |
|---|---|---|
| Clean | 1 baseline | Original decoded RGB, no additional processing |
| JPEG | Q95, Q75, Q50 | Pillow JPEG encode/decode, 4:2:0 chroma subsampling, baseline, no optimization |
| Resize | 0.75, 0.50, 0.25 | One Lanczos downsample of each side, no resize back |
| Crop | 75%, 50%, 25% area | Center crop; side lengths multiplied by square root of retained area; no resampling |
| Blur | sigma 0.5, 1.0, 2.0 px | Pillow GaussianBlur; its documented radius is the Gaussian standard deviation |
| Sharpen | 50%, 100%, 200% | Pillow UnsharpMask, radius 1 px, threshold 0 |
| Resize then JPEG | .75→Q75, .50→Q75, .50→Q50 | Same resize and JPEG definitions in that order |

There are 19 conditions including clean. Pillow's documented filter definitions are at [ImageFilter](https://pillow.readthedocs.io/en/stable/reference/ImageFilter.html). The released model subsequently resizes the residual grid internally, including possible upsampling; that remains part of the measured system.

## Selection and splits

Download authentic public benchmark images. Preserve archive/source identifiers and original file bytes, dimensions, formats, and hashes. Choose deterministic subsets independently of detector outputs. Use calibration real originals only to set an optional operating threshold, and test originals to measure performance. No derivatives cross the local calibration/test boundary. Unknown overlap with the checkpoint authors' unshared training manifests must be stated.

The final manifest and run metadata record actual sources, counts, split seed, selected IDs, conditions, and implementation hashes. Dataset selection will be sized from measured full-resolution throughput, keeping time for analysis within the requested approximately 6–7 hours. A shorter successful run need not consume time artificially; a time-limited run must explicitly report incomplete coverage.

## Outcomes and uncertainty

1. AUROC and average precision, both pooled and per generator, and a generator-macro AUROC. Positive label is synthetic; anomaly score is negative z-score.
2. Real false-positive rate, synthetic true-positive rate, balanced accuracy, and decision flips at the released z threshold −2. A second threshold uses the 95th percentile of clean, separate real calibration scores and stays fixed across test conditions.
3. Paired feature drift: relative L2 and cosine distance for raw FSD and detection-projected features, relative to the same clean original.
4. Residual energy per channel, native residual RMS, post-preprocessing residual RMS, and a native center-patch high-frequency energy fraction. Spatial previews use a shared display scale. Cropped/resized residuals are not treated as aligned pixelwise difference images.
5. Released source-prediction accuracy only where dataset labels match checkpoint generators unambiguously. Report unknown generator predictions descriptively. The release supplies no unknown-rejection mechanism, so this is not called open-set attribution.
6. Bootstrap original IDs within source, reusing the same draws for clean and processed scores. Report 95% intervals for AUROC and paired change. Derived variants are repeated measures, not additional independent images.
7. Exact completion and error counts, runtime, peak allocated GPU memory, environment versions, and original-image counts.

These transformations simulate possible processing workflows. They are not measurements of a particular social platform's current upload/download behavior.

## Interpretation and next experiments

Use results to distinguish loss of ranking quality from a shifted decision threshold. If ranking survives but false alarms rise, test processing-aware real-only calibration on separate development data. If ranking fails, changing the threshold alone cannot restore separability. Examine residual and feature drift by generator before choosing further experiments. Test compound transformations on the same originals to quantify interactions.

Broader scale ablation, efficiency research, and full paper reproduction belong to the other project columns. Cached descriptors may support secondary clustering and attribution analyses without repeating costly extraction, but these should not displace the AN sweep.
