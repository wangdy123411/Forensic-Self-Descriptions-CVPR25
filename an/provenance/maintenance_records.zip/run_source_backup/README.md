# AN — FSD processing robustness

This directory contains the AN contribution from the project-plan slide: paired tests of JPEG, resizing, cropping, blur, sharpening, and resize→JPEG, with residual/960D feature analysis and task metrics.

All new code, downloaded data, weights, environment, logs, and results live under `an/`. The original `fsd/` package is imported without modification.

## Read first

- [Completed results and recommendations](RESULTS.md) — 5,800 cases, zero errors; final verification passed.
- [Completed direct upstream comparison](baseline_comparison/RESULTS.md) — 175 matched default-1024 cases; all detection/source decisions agree, with approximately 15× median paired speedup on this PC.
- [Research and upstream/paper/data audit](docs/research.md)
- [Experiment design and controls](docs/experiment_plan.md)
- [Implementation, numerical fidelity, and timing](docs/implementation_notes.md)
- [Dataset acquisition and provenance](docs/dataset_access.md)
- [Main experiment report](results/main/report.md) — all 300 test originals have all 19 conditions.
- [Weight hashes](weights_provenance.json)
- [Final source and result provenance](source_provenance.json)
- [Completed artifact verification](results/main/verification.json)
- [1024-grid FFT-versus-AN-tiled numerical audit](results/extractor_validation_1024.json)

This evaluates **official upstream main commit `50f2eae06efdac2e5a33f407ca9a27a2295133ac` with explicit v1.2.0 release weights**. The source commit differs from the earlier `v1.2.0` tag in attribution and automatic weight-selection behavior; see [pinned source verification](baseline_comparison/source_verification.md). The paper and release also have material differences, documented in the research notes. This is not a claim to reproduce the paper's original 96-comparison benchmark or its training pipeline.

## Environment

The environment is `an/.venv` (Python 3.12). Invoke its interpreter directly from the repository root; activation is optional:

```powershell
an/.venv/Scripts/python.exe -c "import torch; print(torch.__version__, torch.cuda.get_device_name(0))"
```

To rebuild with an installed Python 3.12:

```powershell
python -m venv an/.venv
an/.venv/Scripts/python.exe -m pip install torch==2.10.0 --index-url https://download.pytorch.org/whl/cu128 --cache-dir an/.cache/pip
an/.venv/Scripts/python.exe -m pip install -r an/requirements-lock.txt --cache-dir an/.cache/pip
an/.venv/Scripts/python.exe an/download_weights.py
```

The actual installed versions are saved in [requirements-lock.txt](requirements-lock.txt);
install the pinned CUDA torch build first, as shown above. The looser
`requirements.txt` is available for adapting to another environment. No Ray
service, Gradio server, or training framework is needed. The run refuses a
silent CPU fallback when CUDA was requested.

## Run and resume

The delivered study uses 100 COCO test originals, 100 separate COCO calibration
originals, and 50 test originals from each of DALL-E 3, Firefly, SDXL, and GLIDE.
This gives 300 test originals × 19 conditions + 100 clean calibration cases =
5,800 scores. RAISE could not be obtained: HTTPS had an expired certificate, and
the HTTP response was not a valid ZIP. No RAISE result is claimed.

The real and synthetic phases use the same signed scoring protocol. They run
sequentially on the GPU; downloading synthetic images overlaps the real phase.
The final `main` directory is a validated analysis-only merge of both phases.

After downloading the dataset using the instructions in [dataset_access.md](docs/dataset_access.md), reproduce into **new output directories**:

```powershell
an/.venv/Scripts/python.exe an/run_experiment.py --manifest an/data/manifest_real.csv --output an/results/real_repeat --device cuda --method fft --calibration-count 100 --hours 1.2
an/.venv/Scripts/python.exe an/run_experiment.py --manifest an/data/manifest_fake.csv --output an/results/fake_repeat --device cuda --method fft --calibration-count 100 --hours 2
an/.venv/Scripts/python.exe an/merge_runs.py an/results/real_repeat an/results/fake_repeat --output an/results/main_repeat
an/.venv/Scripts/python.exe an/analyze_results.py an/results/main_repeat --bootstrap 1000
```

The precise commands are in each phase's `run_metadata.json`; the merged run
preserves those snapshots and file hashes. A rerun of an original phase with
the same configuration resumes completed image-condition records. Changing
weights, selected images, extraction/processing code, or configuration requires
a different output directory. Merged directories cannot be resumed for scoring.
`--hours` is a limit for that invocation and is checked between originals so a
19-condition group can finish. Creating a file named `STOP` in a scoring run
directory requests a graceful stop after the current original.

Use `--limit-per-source N` for a smaller pilot. Do not compare a pilot with `--max-size` changed to the official 1024-setting study as if they were the same model. The default extraction preserves the official configuration.

## Outputs

- `data/manifest_real.csv` and `manifest_fake.csv`: frozen original IDs, local paths, source labels, calibration/test split, hashes, native encodings, and origin metadata.
- `results/<run>/run_metadata.json`: selection, expected coverage, model configuration, runtime environment, implementation hashes, and session commands.
- `records.jsonl`: one row per successfully scored original-condition pair, including scores, drift, residual diagnostics, runtime, and peak allocated GPU memory.
- `features/*.npz`: raw 960D, detection-projected, and attribution-projected vectors, allowing additional analyses without another GPU pass.
- `previews/` and `examples/`: selected residual tensors and small processed-image previews.
- `progress.json` and `errors.jsonl`: completion and explicit failures. Missing records are never treated as successes.
- Analysis CSVs, PNGs, and `report.md`: detection metrics, paired uncertainty, source predictions, and interpretation.

Large downloaded images, environment/cache files, and per-image feature/previews are ignored by `an/.gitignore`; numeric summaries and study code are reviewable. Preserve local ignored artifacts if full reproduction of the exact run is needed.

## Verification

```powershell
an/.venv/Scripts/python.exe -m unittest discover -s an/tests
an/.venv/Scripts/python.exe an/tests/validate_extractor.py --weights an/weights/v1.2.0 --device cuda --max-size 1024 --skip-upstream --output an/results/extractor_validation_rerun.json
```

The numerical fixture in the validation command tests implementation agreement, not detection accuracy. With `--skip-upstream`, its 1024-setting reference is the AN direct tiled extractor, not a literal call to the original full-patch function. Real benchmark results come from the manifest-based experiment. The FFT acceleration retains all samples/scales and float64, reconstructs the Gram matrix from correlations, and explicitly corrects reflection boundaries. Numerical agreement within recorded tolerances against the AN tiled reference was checked before production; the separate [direct upstream follow-up](baseline_comparison/README.md) executes the original function at its default 1024 setting.

## Interpretation boundaries

Calibration originals and test originals are separate locally; original checkpoint training manifests are unavailable, so checkpoint-level overlap cannot be excluded. Processing simulations do not represent measured behavior of a named social-media service. Released source prediction is a closed-set argmax with no unknown rejection, and cannot alone establish open-set attribution robustness. Residual/feature drift is descriptive evidence of sensitivity rather than a causal proof.

All selected COCO and Firefly originals are JPEG-encoded; Firefly's archive names
end in `.png`, so native encoding is determined from file contents. The other
selected synthetic sources are PNG-encoded. "Clean" means no added processing
by this experiment, not a guarantee of an uncompressed generation history.

Upstream code and weights are [CC BY-NC-SA 4.0](../LICENSE); cite the FSD paper and each dataset used. Dataset access terms remain applicable.
