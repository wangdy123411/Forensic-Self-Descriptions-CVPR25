"""Run or resume the paired upstream comparison, then its independent analysis."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent


def status(stage, **extra):
    value = dict(stage=stage, updated_utc=datetime.now(timezone.utc).isoformat(), **extra)
    temporary = BASE / "pipeline_status.tmp"
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(BASE / "pipeline_status.json")
    print(json.dumps(value), flush=True)


def run(stage, args):
    command = [sys.executable, *args]
    status(stage, command=command)
    with (BASE / f"{stage}.log").open("a", encoding="utf-8", buffering=1) as log:
        log.write(f"\nStarted {datetime.now(timezone.utc).isoformat()}\n")
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"{stage} returned {result.returncode}; inspect {stage}.log")


def main():
    run("comparison", ["an/baseline_comparison/compare_upstream.py", "--hours", "6"])
    progress = json.loads((BASE / "run1024/progress.json").read_text())
    if progress["state"] != "complete":
        raise RuntimeError(f"Comparison stopped before full coverage: {progress}")
    run(
        "analysis",
        [
            "an/baseline_comparison/analyze_comparison.py",
            "an/baseline_comparison/run1024",
            "--require-complete",
        ],
    )
    summary = json.loads((BASE / "run1024/comparison_summary.json").read_text())
    status(
        "complete",
        report=str(BASE / "run1024/report.md"),
        numeric_pass=summary["independently_recomputed_numeric_pass"],
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        status("error", error=str(error))
        raise
    finally:
        (BASE / "gpu_telemetry.stop").write_text("Comparison controller stopped.\n")
