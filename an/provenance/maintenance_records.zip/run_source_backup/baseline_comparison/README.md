# Direct upstream comparison

**Completed: 175/175 matched cases, zero errors, all detection/source decisions agree.** Start with [results and interpretation](RESULTS.md), then the [full audit report](run1024/report.md). The final test suite passes all 38 tests.

This follow-up runs the original released implementation on this PC and compares it with the AN implementation on identical inputs. It supplements the earlier numerical tests, whose 1024-setting reference was the memory-efficient tiled extractor rather than a literal run of the original extraction function.

## Executed configuration and selection

The comparison uses **official upstream main commit `50f2eae06efdac2e5a33f407ca9a27a2295133ac` with explicit v1.2.0 release weights**. It keeps float64 computation, three scales, 11×11 FSD neighborhood, internal `max_size=1024`, and `resize_and_crop` preprocessing. The original `fsd/` files are not edited. [Source verification](source_verification.md) proves the checkout matches the observed official main and documents why the earlier `v1.2.0` tag must not be conflated with this commit.

`manifest.csv` freezes 25 original test images: five each from COCO, DALL-E 3, Firefly, SDXL, and GLIDE. Selection uses a deterministic hash of the image ID and seed, without scores. `selection.json` preserves the selection procedure and the original 19-condition candidate grid. To make a direct default-setting comparison practical on this machine, the executed comparison uses seven representative conditions:

- clean;
- JPEG Q50;
- half-size resizing;
- center cropping to 25% area;
- Gaussian blur radius 2;
- unsharp mask amount 200%;
- half-size resizing followed by JPEG Q50.

This gives **175 matched cases**. The same 25 originals and seven conditions must be used on both sides of every task-metric comparison. A 25-image upstream result must never be compared directly with the earlier 300-image AN headline as if differences were caused by implementation.

## What is compared

1. Literal public-API probes call `FSDDetector.attribute` at the default settings. `audit_api_probes.py` compares their z-scores, source labels, decisions, confidence, and all 14 source probabilities with the saved AN records. The main records contain raw source log likelihoods, so the audit converts them with the original temperature-750 softmax before comparing probabilities.
2. The larger matched run calls the original `FSDDetector.compute_fsd` without replacing its extraction function, then uses the original projection, GMM, and attribution functions. It compares raw/projected/attribution descriptors and outputs with the saved main features and a fresh AN extraction where recorded.
3. Task metrics are recomputed on this exact matched cohort. These small-sample metrics are for implementation validation, not a new estimate of general population accuracy. Supported-source attribution accuracy excludes GLIDE; implementation-level agreement can still compare its predicted labels.

Numeric checks retain the earlier relative-FSD tolerance `1e-4` and absolute-z tolerance `1e-3`; probability agreement is checked at `1e-4`. Discrete detection/source disagreements are reported explicitly rather than hidden by those tolerances. Every original and processed input is identified and hashed where recorded, and incomplete cases must remain visible.

## Hardware finding

The original function materializes about **9.93 GiB** of patch tensors at the default grid, exceeding the RTX 2060's 6 GiB physical memory. Nevertheless, literal default-setting public-API probes **succeeded** on this Windows machine. The first two took about 93 and 73 seconds, with logical PyTorch allocation around 10.7 GiB. GPU/system-memory observations are consistent with Windows/NVIDIA shared-memory fallback and paging; this is an inference, not a direct residency trace.

Thus the original implementation can run here, and the comparison does **not** lower resolution. The AN extractor avoids those large allocations. Logical CUDA allocation, physically resident VRAM, system RAM, and runtime must be distinguished. Timing reflects the current machine/allocator state and possible memory fallback; it is not a universal hardware-independent speedup.

All follow-up files remain under `an/baseline_comparison/`; the completed main predictions and original frozen manifests remain unchanged. The completed report records full coverage and no decision/source mismatches.

## Run and inspect

The controller runs or resumes the 175 cases, then independently audits and analyzes the completed pairs:

```powershell
an/.venv/Scripts/python.exe an/baseline_comparison/complete_comparison.py
```

Completion state is in `pipeline_status.json` and `run1024/progress.json`. The [comparison report](run1024/report.md) records all 175 cases. [Public API checks](api_probe_audit.json) are separate from the paired timing run. Recorded allocation values are logical, and retained allocator/cache state can affect both implementations' timings even with alternating execution order. The battery interruption is retained in overall results and separately flagged in [timing strata](run1024/runtime_power_strata.csv).

After report edits, `finalize_provenance.py` writes a separate [final comparison inventory](final_provenance.json), preserving the earlier `an/source_provenance.json` snapshot.
