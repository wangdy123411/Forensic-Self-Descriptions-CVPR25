# CVPR 2026 experiments subsection

The deliverable is a two-column CVPR-style excerpt with one table and one vector plot. The subsection and its visuals occupy roughly three-quarters of a page; the standalone PDF also includes three references on the same page. The document uses the unmodified official CVPR 2026 style at commit `12909ae437f6dbc7435069cfdb4ca44c18e6a02f`, rather than the repository's newer 2027 main branch. The standard body font and page geometry are unchanged. The standalone wrapper uses ragged column bottoms to avoid stretching a short excerpt to fill the page.

Revised 9 November 2026 for more fluent prose, fewer parenthetical details, core settings only, and a shorter discussion. The reasoning behind the test families, matched dimensions, fixed model configuration, and complementary metrics is retained. Exact settings follow `../docs/experiment_plan.md` and `../robustness/transforms.py`. The seven displayed settings are illustrative selections from the full 19-condition sweep, not claimed to be optimal or the strongest settings in every family. Half-size resize and the nominal 25%-area crop produce equal output dimensions for all 300 originals, but differ in content and sampling; this is not a causal isolation of interpolation. Earlier versions are preserved locally under `revisions/v1/` and `revisions/v2/`.

## Files

- `output/pdf/robustness_subsection.pdf`: compiled final excerpt.
- `main.tex`: standalone wrapper, with an illustrative Section 4, Experiments.
- `subsection.tex`: insertable experiments subsection.
- `processing_table.tex`: table generated from saved main-study metrics.
- `figures/generator_sensitivity.pdf`: vector figure included in the document.
- `references.bib`: the three cited works; keys can be merged into an existing bibliography.
- `make_assets.py`: reproduces the table/figure from the original repository's saved metrics.
- `build.py`: local compiler and PDF preview helper.
- `template_provenance.json`, `latex_dependencies.json`, and `data_provenance.json`: source records.
- `artifact_verification.json`: page count, source hashes, and final checks.

The 300-original processing study and the 25-original, 175-case upstream validation are kept separate. The change evaluated is FFT accumulation in the released inference pipeline, with fixed weights and preprocessing. Its measured benefit is efficiency; no robustness mitigation was trained or validated. Controlled processing is explicitly distinguished from observed social-media transformations. The residual statistic is a median of paired ratios after internal residual preprocessing. Memory numbers are logical PyTorch allocations, not physical VRAM residency.

## Technical details omitted from the short subsection

The complete processing grid uses JPEG Q95/Q75/Q50 with 4:2:0 chroma subsampling; Lanczos resizing to 0.75/0.50/0.25 of each side; center crops retaining 75/50/25% of image area; Gaussian blur radii 0.5/1/2 pixels; and unsharp masking at 50/100/200%, with radius 1 pixel and threshold 0. Sequential cases are resize 0.75 then JPEG Q75, resize 0.50 then Q75, and resize 0.50 then Q50. Processing precedes the released grayscale and residual pipeline. Its internal 1024-grid resizing can upsample inputs. All extraction retains float64 and three scales.

The upstream check uses unmodified commit `50f2eae06efdac2e5a33f407ca9a27a2295133ac` and explicit v1.2.0 weights for both implementations. The 25 originals comprise five per source. Timings include extraction, scoring and diagnostics and reflect the allocator state in the comparison harness. The median paired speedup is 15.07 times; excluding five cases overlapping the battery interruption gives 15.05 times. Peak allocation measures logical tensor memory, not a direct trace of physical VRAM use.

Uncertainty uses 1,000 source-stratified bootstrap draws of original IDs, with paired multiplicities reused across conditions. For half-size resizing, the paired macro-AUROC change is -0.4055 with a 95% interval of [-0.4376, -0.3773]. Plot intervals are pointwise and conditional on the selected sources and model. The residual statistic in the prose is the median of each image's processed-to-clean RMS ratio after internal preprocessing; the descriptor statistic is the median raw 960D relative L2 drift. The main table uses the released threshold, not the separately available clean-real calibration threshold.

## Reuse in a larger paper

Copy `subsection.tex`, `processing_table.tex`, and the vector figure into the paper project. Set `\graphicspath{{figures/}}` (or adapt the figure path), then place `\input{subsection}` inside the Experiments section. Merge the three entries in `references.bib`. Normal CVPR packages provide all required commands. Figure/table numbering will follow the surrounding paper; adjust float placement to suit its layout. The `samepage` group keeps the implementation-comparison paragraph together in this excerpt and may be removed when integrating it into a full paper.

The source archive includes all required figure/table assets; regenerating them is not required for compilation. The small `texmf/` directory contains missing LaTeX packages for this PC. Standard complete TeX Live installations and Overleaf normally already provide them. Their upstream files are unchanged.

## Build locally

With this repository's virtual environment and the installed TeX distribution, run from the repository root:

```powershell
an/.venv/Scripts/python.exe an/paper_cvpr2026/build.py
```

This invokes pdfLaTeX, BibTeX, then pdfLaTeX twice. Python requires `pypdf`; `pdftoppm` renders previews when available. Compilation uses project-local missing LaTeX dependencies and does not alter the installed TeX tree. To recreate the table/plot from the frozen experiment CSV:

```powershell
an/.venv/Scripts/python.exe an/paper_cvpr2026/make_assets.py
an/.venv/Scripts/python.exe an/paper_cvpr2026/build.py
```

In a complete TeX installation or Overleaf, compile `main.tex` with pdfLaTeX and BibTeX directly. Python is unnecessary when using the supplied table and vector figure. All source inputs are UTF-8.

## Evidence and citation sources

Main numerical evidence: `../results/main/metrics.csv`, `../results/main/records.jsonl`, and `../results/main/attribution_metrics.csv`. Upstream comparison: `../baseline_comparison/run1024/comparison_summary.json`, `runtime.csv`, and `runtime_power_strata.csv`. The paper-generating code does not change these artifacts or rerun inference.

- [Official CVPR 2026 author guidelines](https://cvpr.thecvf.com/Conferences/2026/AuthorGuidelines).
- [Pinned CVPR 2026 template](https://github.com/cvpr-org/author-kit/tree/12909ae437f6dbc7435069cfdb4ca44c18e6a02f).
- [FSD author manuscript and author metadata](https://arxiv.org/abs/2503.21003); conference pagination is recorded in the official implementation's BibTeX.
- [COCO preprint and author metadata](https://arxiv.org/abs/1405.0312); the bibliography deliberately cites this version.
- [Synthbuster dataset record](https://zenodo.org/records/10066460).

No unpublished mitigation result, causal explanation of descriptor changes, or full reproduction of the paper's original benchmark is claimed.
