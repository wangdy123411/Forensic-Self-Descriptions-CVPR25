"""Finish the already-started real phase, fake phase, merge, and analysis.

This helper does not download or alter data selection. It waits for the explicit
200-image download and existing real phase, then executes the recorded protocol.
It keeps stdout/stderr logs and a status file beneath an/.
"""
from __future__ import annotations
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time

AN = Path(__file__).resolve().parent
REPO = AN.parent
PYTHON = str(AN / ".venv" / "Scripts" / "python.exe")
LOGS = AN / "logs"
STATUS = AN / "results" / "pipeline_status.json"


def status(stage, **extra):
    value = dict(stage=stage, updated_utc=datetime.now(timezone.utc).isoformat(), **extra)
    tmp = STATUS.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, indent=2))
    tmp.replace(STATUS)
    print(json.dumps(value), flush=True)


def run(stage, arguments):
    command = [PYTHON] + arguments
    status(stage, command=command)
    with (LOGS / f"{stage}.log").open("a", encoding="utf-8", buffering=1) as log:
        log.write(f"\nStarted {datetime.now(timezone.utc).isoformat()}\n")
        result = subprocess.run(command, cwd=REPO, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"{stage} failed with exit {result.returncode}; see {LOGS / (stage + '.log')}")


def main():
    LOGS.mkdir(parents=True, exist_ok=True)
    STATUS.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + 3 * 3600
    status("waiting_for_real_phase_and_fake_download")
    wanted = {"DALL-E 3", "Adobe Firefly", "Stable Diffusion XL", "GLIDE"}
    while True:
        if time.monotonic() >= deadline:
            raise TimeoutError("Setup/real phase did not finish within helper's 3-hour limit")
        real_file = AN / "results" / "real_phase" / "progress.json"
        real = json.loads(real_file.read_text()) if real_file.exists() else {}
        if real.get("state") in {"incomplete_errors", "time_limit"}:
            raise RuntimeError(f"Real phase stopped incomplete: {real}")
        fake_file = AN / "data" / "manifest_synthbuster.csv"
        counts = {}
        if fake_file.exists():
            with fake_file.open(newline="", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    counts[row["source"]] = counts.get(row["source"], 0) + 1
        ready = all(counts.get(name, 0) >= 50 for name in wanted)
        if ready and not (AN / "data" / "manifest_fake.csv").exists():
            run("freeze_fake_manifest", ["an/prepare_manifest.py", "--per-source", "50", "--coco-test", "0",
                "--coco-calibration", "0", "--raise-test", "0", "--raise-calibration", "0",
                "--output", "an/data/manifest_fake.csv"])
            status("waiting_for_real_phase", fake_download_complete=True, fake_manifest_frozen=True)
        if ready and real.get("state") == "complete":
            break
        time.sleep(15)
    run("fake_phase", ["an/run_experiment.py", "--manifest", "an/data/manifest_fake.csv",
        "--output", "an/results/fake_phase", "--device", "cuda", "--method", "fft",
        "--calibration-count", "100", "--hours", "2.0"])
    fake = json.loads((AN / "results" / "fake_phase" / "progress.json").read_text())
    if fake.get("state") != "complete":
        raise RuntimeError(f"Fake phase stopped incomplete: {fake}")
    run("merge", ["an/merge_runs.py", "an/results/real_phase", "an/results/fake_phase",
                   "--output", "an/results/main"])
    run("analysis", ["an/analyze_results.py", "an/results/main", "--bootstrap", "1000"])
    status("complete", report=str(AN / "results" / "main" / "report.md"))
    (AN / "results" / "gpu_telemetry.stop").write_text("Experiment and analysis completed.\n")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        status("error", error=str(exc))
        raise
