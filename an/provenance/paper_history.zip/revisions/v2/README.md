# CVPR 2026 experiments subsection

The deliverable is a one-page, two-column CVPR-style excerpt, including one table, one vector plot, and three references. The experimental discussion occupies approximately 0.85 page; the compact reference list occupies the remaining space. The document uses the unmodified official CVPR 2026 style at commit `12909ae437f6dbc7435069cfdb4ca44c18e6a02f`, rather than the repository's newer 2027 main branch. The standard body font and page geometry are unchanged.

Revised 9 November 2026 to emphasize the reasoning behind the test families, severity ranges, paired design, fixed model configuration, and complementary metrics. Exact settings follow `../docs/experiment_plan.md` and `../robustness/transforms.py`. The seven displayed settings are illustrative selections from the full 19-condition sweep, not claimed to be optimal or the strongest settings in every family. Half-size resize and the nominal 25%-area crop produce equal output dimensions for all 300 originals, but differ in content and sampling; this is not a causal isolation of interpolation. The previous version is preserved locally under `revisions/v1/`.

## Files

- `output/pdf/robustness_subsection.pdf`: compiled final excerpt.
- `main.tex`: standalone wrapper, with an illustrative Section 4, Experiments.
- `subsection.tex`: insertable experiments subsection.
- `processing_table.tex`: table generated from saved main-study metrics.
- `figures/generator_sensitivity.pdf`: vector figure included in the document.
- `references.bib`: the three cited works; keys can be merged into an existing bibliography.
- `make_assets.py`: reproduces the table/figure from the original repository's saved metrics.
- `build.py`: local compiler and PDF preview helper.
- `template_provenance.json`, `latex_dependencies.json`, and `data_provenance.json`: source records.
- `artifact_verification.json`: page count, source hashes, and final checks.

The 300-original processing study and the 25-original, 175-case upstream validation are kept separate. The change evaluated is FFT accumulation in the released inference pipeline, with fixed weights and preprocessing. Its measured benefit is efficiency; no robustness mitigation was trained or validated. Controlled processing is explicitly distinguished from observed social-media transformations. The residual statistic is a median of paired ratios after internal residual preprocessing. Memory numbers are logical PyTorch allocations, not physical VRAM residency.

## Reuse in a larger paper

Copy `subsection.tex`, `processing_table.tex`, and the vector figure into the paper project. Set `\graphicspath{{figures/}}` (or adapt the figure path), then place `\input{subsection}` inside the Experiments section. Merge the three entries in `references.bib`. Normal CVPR packages provide all required commands. Figure/table numbering will follow the surrounding paper; adjust float placement to suit its layout.

The source archive includes all required figure/table assets; regenerating them is not required for compilation. The small `texmf/` directory contains missing LaTeX packages for this PC. Standard complete TeX Live installations and Overleaf normally already provide them. Their upstream files are unchanged.

## Build locally

With this repository's virtual environment and the installed TeX distribution, run from the repository root:

```powershell
an/.venv/Scripts/python.exe an/paper_cvpr2026/build.py
```

This invokes pdfLaTeX, BibTeX, then pdfLaTeX twice. Python requires `pypdf`; `pdftoppm` renders previews when available. Compilation uses project-local missing LaTeX dependencies and does not alter the installed TeX tree. To recreate the table/plot from the frozen experiment CSV:

```powershell
an/.venv/Scripts/python.exe an/paper_cvpr2026/make_assets.py
an/.venv/Scripts/python.exe an/paper_cvpr2026/build.py
```

In a complete TeX installation or Overleaf, compile `main.tex` with pdfLaTeX and BibTeX directly. Python is unnecessary when using the supplied table and vector figure. All source inputs are UTF-8.

## Evidence and citation sources

Main numerical evidence: `../results/main/metrics.csv`, `../results/main/records.jsonl`, and `../results/main/attribution_metrics.csv`. Upstream comparison: `../baseline_comparison/run1024/comparison_summary.json`, `runtime.csv`, and `runtime_power_strata.csv`. The paper-generating code does not change these artifacts or rerun inference.

- [Official CVPR 2026 author guidelines](https://cvpr.thecvf.com/Conferences/2026/AuthorGuidelines).
- [Pinned CVPR 2026 template](https://github.com/cvpr-org/author-kit/tree/12909ae437f6dbc7435069cfdb4ca44c18e6a02f).
- [FSD author manuscript and author metadata](https://arxiv.org/abs/2503.21003); conference pagination is recorded in the official implementation's BibTeX.
- [COCO preprint and author metadata](https://arxiv.org/abs/1405.0312); the bibliography deliberately cites this version.
- [Synthbuster dataset record](https://zenodo.org/records/10066460).

No unpublished mitigation result, causal explanation of descriptor changes, or full reproduction of the paper's original benchmark is claimed.
